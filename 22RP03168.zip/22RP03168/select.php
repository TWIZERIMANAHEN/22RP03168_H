<?php
$conn = mysqli_connect("localhost", "root", "", "class");
$select = mysqli_query($conn, "SELECT * FROM student");
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Student List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        a {
            text-decoration: none;
            color: #007BFF;
        }
        a:hover {
            color: #0056b3;
        }
        .action-button {
            background-color: #ff4d4d;
            color: white;
            padding: 8px 16px;
            border-radius: 4px;
            display: inline-block;
        }
         .insert {
            background-color: #ff4d4d;
            color: white;
            padding: 8px 16px;
            border-radius: 4px;
            display: inline-block;
            position: relative;
            
        }
        .action-logout {
            background-color: #ff4d4d;
            color: white;
            padding: 8px 16px;
            border-radius: 4px;
            display: inline-block;
            position: relative;
            left: 840px;
        }
        .action-button:hover {
            background-color: #e60000;
        }
    </style>
</head>
<body><a href='form.php' class='insert'>Insert New</a>
	<a href='logout.php' class='action-logout'>logout</a>
    <center>
        <center><h2>List of All Students in School</h2></center>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tel</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Comment</th>
                    <th>File</th>
                    <th>Image</th>
                    <th colspan='2'>Action</th>
                </tr>
            </thead>
            <tbody>
<?php
while ($fetch = mysqli_fetch_array($select)) {
    $id = $fetch['id'];
    echo "<tr>
            <td>".$fetch['id']."</td>
            <td>".$fetch['tel']."</td>
            <td>".$fetch['username']."</td>
            <td>".$fetch['password']."</td>
            <td>".$fetch['email']."</td>
            <td>".$fetch['age']."</td>
            <td>".$fetch['gender']."</td>
            <td>".$fetch['comment']."</td>
            <td>".$fetch['file']."</td>
            <td>".$fetch['image']."</td>
            <td><a href='update.php?id=$id' class='action-button'>Update</a></td>
            <td><a href='delete.php?id=$id' class='action-button'>Delete</a></td>
        </tr>";
}
?>

</tbody>
        </table>
    </center>
</body>
</html>
