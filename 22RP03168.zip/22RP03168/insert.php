<?php
include('connection.php');  
if(isset($_POST['send'])){
	$id=$_POST['id'];
	$tel=$_POST['tel'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$email=$_POST['email'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$comment=$_POST['comment'];
	$file=$_POST['file'];
	$image=$_POST['image'];
	$query=mysqli_query($con,"insert into student(id,tel,username,password,email,age,gender,comment,file,image)values('$id','$tel','$username','$password','$email','$age','$gender','$comment','$file','$image')");
	if($query==true)
	{
		header("Location: select.php");
	}
	else {
		echo "data is not inserted";
	}
}
?>