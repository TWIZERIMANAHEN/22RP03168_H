<?php
include('connection.php');

if(isset($_POST['update'])){
 $id=$_POST['id'];
    $tel=$_POST['tel'];
    $username=$_POST['username'];
     $password=$_POST['password'];
    $email=$_POST['email'];
     $age=$_POST['age'];
    $gender=$_POST['gender'];
    $comment=$_POST['comment'];
     $file=$_POST['file'];
      $image=$_POST['image'];
    $res=mysqli_query($con,"UPDATE student SET tel='$tel',username='$username',password='$password',email='$email', age='$age',gender='$gender',comment='$comment',file='$file',image='$image'WHERE id='$id' ");
   if($res){
    echo "data updated";
  header("Location: select.php");
   }
   else{
    echo"not update";
   }
}
?>



<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
</head>
<body>
    <fieldset style="width: 300px;background-color: pink">
    <form action="" method="POST">
        <center>
            <h1>Registration Form</h1>
            <table>
              <tr>
                    <td>id</td>
                    <td><input type="number" name="id" required></td>
                </tr>
                <tr>
                    <td>Tel</td>
                    <td><input type="number" name="tel" required></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="text" name="username" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="email" name="email" required></td>
                </tr>
                <tr>
                    <td>Age</td>
                    <td><input type="number" name="age" required></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>
                        <select name="gender" required>
                            <option value="M">M</option>
                            <option value="F">F</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Comment</td>
                    <td><input type="text" name="comment"></td>
                </tr>
                <tr>
                    <td>File</td>
                    <td><input type="file" name="file"></td>
                </tr>
                <tr>
                    <td>Image</td>
                    <td><input type="file" name="image"></td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <input type="submit" name="update" value="update"><input type="reset" name="ssubmit" value="clear"> 
                    </td>
                </tr>
            </table>
        </center>
    </form>
    </fieldset>
</body>
</html>

